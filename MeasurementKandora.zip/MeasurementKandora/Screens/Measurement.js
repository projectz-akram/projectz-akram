import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    Dimensions,
    StatusBar
} from 'react-native';
const { width: WIDTH } = Dimensions.get('window')
import AppLoading from 'expo-app-loading';
import * as Font from 'expo-font';
let customFonts = {
    'Hamelin': require('./assets/fonts/FontsFree-Net-Hamelin.ttf'),
    'caveat': require('./assets/fonts/Caveat-Medium.ttf'),
    'hambold': require('./assets/fonts/Hamlin-Bold.ttf'),
    'hamextrabold': require('./assets/fonts/Hamlin-ExtraBold.ttf'),
    'hamlight': require('./assets/fonts/Hamlin-Light.ttf'),
    'hamregular': require('./assets/fonts/Caveat-Medium.ttf'),
};
class Measurement extends React.Component {
    state = {
        fontsLoaded: false,
    };
    async _loadFontsAsync() {
        await Font.loadAsync(customFonts);
        this.setState({ fontsLoaded: true });
    }
    componentDidMount() {
        this._loadFontsAsync();
    }
    render() {
        if (this.state.fontsLoaded) {
            return (
                <View style={{ flex: 1 }}>
                    <StatusBar
                    backgroundColor="#181b51"
                   
                />
                    <View style={{ flex: 1.5, backgroundColor: "#181b51", margin: 1 }}>
                        <View style={{ flex: 1, width: null, height: null, justifyContent: 'center', alignItems: 'center' }}>
                            <Image source={require('./assets/cancanlogow.png')} style={styles.logo} />
                            <Text style={{ color: '#fff', fontSize: 20, margin: 5, marginBottom: 5, fontFamily: 'hamextrabold' }}>WELCOME!</Text>
                            <Text style={{ color: '#fff', fontSize: 15, fontFamily: 'hamextrabold' }}>LOGIN TO YOUR ACCOUNT</Text>
                        </View>
                    </View>
                    <View style={{ flex: 3, backgroundColor: "#fff", margin: 1, justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableOpacity style={{ backgroundColor: '#181b51', borderRadius: 100, marginBottom: 100 }} onPress={() => { this.props.navigation.navigate('LogIn') }}>
                            <Text style={{ color: '#fff', padding: 10, paddingLeft: 50, paddingRight: 50, fontFamily: 'hamextrabold' }}>LOGIN WITH EMAIL</Text>
                        </TouchableOpacity>
                        <Text style={{ fontSize: 20, color: "#181b51", fontFamily: 'hamextrabold' }}>--------------- or --------------</Text>
                    </View>
                    <View style={{ flex: 0.5, backgroundColor: "#fff", margin: 1, justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableOpacity style={{ backgroundColor:'#fff',borderRadius:100,borderWidth: 1, borderColor: "#181b51" }}
                            onPress={() => { this.props.navigation.navigate('Register') }}>
                            <Text style={{ color: '#181b51', padding: 10, paddingLeft: 50, paddingRight: 50, fontFamily: 'hamextrabold' }}>CREATE AN ACCOUNT</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            )
        }
        else {
            return <AppLoading />;
        }
    }
}
const styles = StyleSheet.create(
    {
        logo: {
            width: 65,
            height: 70,
        },
    }
)
export default Measurement;