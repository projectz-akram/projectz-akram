import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    CheckBox
} from 'react-native';
import AppLoading from 'expo-app-loading';
import * as Font from 'expo-font';
let customFonts = {
    'Hamelin': require('./assets/fonts/FontsFree-Net-Hamelin.ttf'),
    'caveat': require('./assets/fonts/Caveat-Medium.ttf'),
    'hambold': require('./assets/fonts/Hamlin-Bold.ttf'),
    'hamextrabold': require('./assets/fonts/Hamlin-ExtraBold.ttf'),
    'hamlight': require('./assets/fonts/Hamlin-Light.ttf'),
    'hamregular': require('./assets/fonts/Caveat-Medium.ttf'),
};
class GetHelp extends React.Component {
    state = {
        fontsLoaded: false,
        Checked: false
    };
    onChangeCheck() {
        this.setState({ checked: !this.state.checked })
    }
    async _loadFontsAsync() {
        await Font.loadAsync(customFonts);
        this.setState({ fontsLoaded: true });
    }
    componentDidMount() {
        this._loadFontsAsync();
    }
    render() {
        if (this.state.fontsLoaded) {
            return (
                <View style={{ flex: 1, }}>
                    <View style={{ flex: 0.2, justifyContent: 'flex-end', marginLeft: 30 }}>
                        <TouchableOpacity onPress={() => this.props.navigation.goBack()}>
                            <Image source={require('./assets/arrowpng.png')} style={{ width: 60, height: 60 }} />
                        </TouchableOpacity>
                    </View>
                    <View style={styles.textheading}>
                        <Text style={{ textAlign: 'center', marginLeft: 50, marginRight: 50, marginBottom: 20, fontSize: 15, fontFamily: 'hamextrabold' }}>HOW TO GET MEASURED WITH 2 PICTURES
                        USING KANDORA MEASUREMENT ?
                     </Text>
                    </View>
                    <View style={styles.imagestyle}>
                        <Image source={require('./assets/selfi.png')} style={styles.logo} />
                        <Image source={require('./assets/backside.png')} style={styles.logo} />
                    </View>
                    <View style={{ flex: 0.05, flexDirection: 'row', justifyContent: 'space-around' }}>
                        <Text style={{ marginLeft: 18, fontFamily: 'hamextrabold' }}>SELFIE MODE</Text>
                        <Text style={{ fontFamily: 'hamextrabold' }}>HELP FROM FRIEND</Text>
                    </View>
                    <View style={{ flex: 0.1, flexDirection: 'row', justifyContent: 'space-around' }}>
                        <View style={{ flex: 0.5, flexDirection: 'row', justifyContent: 'center' }}>
                            <Image source={require('./assets/play.jpg')} style={{ width: 25, height: 25, tintColor: "#181b51" }} />
                            <Text style={{ marginLeft: 12, color: '#181b51', fontSize: 17, fontFamily: 'hamextrabold' }}>PLAY</Text>
                        </View>
                        <View style={{ flex: 0.5, flexDirection: 'row', justifyContent: 'center' }}>
                            <Image source={require('./assets/play.jpg')} style={{ width: 25, height: 25, tintColor: "#181b51" }} />
                            <Text style={{ marginLeft: 12, color: '#181b51', fontSize: 17, fontFamily: 'hamextrabold' }}>PLAY</Text>
                        </View>
                    </View>
                    <View style={{ flex: 0.2, justifyContent: 'flex-end', }}>
                        <View style={{ flexDirection: 'row', margin: 20 }}>

                            <CheckBox

                                value={this.state.checked}
                                onChange={() => this.onChangeCheck()}


                            />


                            <Text style={{ marginLeft: 15, fontSize: 17, fontFamily: 'hamextrabold' }}>Don't show me this screen again</Text>
                        </View>
                    </View>
                    <TouchableOpacity style={{ flex: 0.1, backgroundColor: "#181b51", justifyContent: 'center', alignItems: 'center' }}
                        onPress={() => { this.props.navigation.navigate('MeasurementInput') }}>
                        <Text style={{ fontSize: 17, color: '#fff', fontFamily: 'hamextrabold' }}>GET STARTED</Text>
                    </TouchableOpacity>
                </View>
            )
        }
        else {
            return <AppLoading />;
        }
    }
}
const styles = StyleSheet.create(
    {
        logo: {
            width: 120,
            height: 150,
        },
        textheading: {
            flex: 0.3,
            justifyContent: 'flex-end',
            alignItems: 'flex-end',

        },
        imagestyle: {
            flex: 0.3,
            flexDirection: 'row',
            justifyContent: 'space-around',
            marginLeft: 20,
            marginRight: 20,
            marginBottom: 10
        }
    }
)
export default GetHelp;