import React from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ImageBackground,
  Image,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  BackHandler,
  Alert
} from 'react-native';
const { width: WIDTH } = Dimensions.get('window')
import AppLoading from 'expo-app-loading';
import Spinner from 'react-native-loading-spinner-overlay';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Feather from 'react-native-vector-icons/Feather';
import * as Animatable from 'react-native-animatable';
import AsyncStorage from '@react-native-async-storage/async-storage';

import * as Font from 'expo-font';
let customFonts = {
  'Hamelin': require('./assets/fonts/FontsFree-Net-Hamelin.ttf'),
  'caveat': require('./assets/fonts/Caveat-Medium.ttf'),
  'hambold': require('./assets/fonts/Hamlin-Bold.ttf'),
  'hamextrabold': require('./assets/fonts/Hamlin-ExtraBold.ttf'),
  'hamlight': require('./assets/fonts/Hamlin-Light.ttf'),
  'hamregular': require('./assets/fonts/Caveat-Medium.ttf')
};
class LogIn extends React.Component {

  constructor() {
    super()
    this.state = {
      username: null,
      email: null,
      password: null,
      fontsLoaded: false,
      spinner: false,
      originalview: true,
      Toast: false,
      Toast1: false,
      Toast2: false,
      check_textInputChange: false,
      secureTextEntry: true,
      isValidUser: true,
      isValidPassword: true,
      token: "",
      user_id: "",
    }
  }

  backAction = () => {
    Alert.alert("Hold on!", "Are you sure you want to go back?", [
      {
        text: "Cancel",
        onPress: () => null,
        style: "cancel"
      },
      { text: "YES", onPress: () => BackHandler.exitApp() }
    ]);
    return true;
  };




  textInputChange = (val) => {
    if (val.trim().length >= 4) {
      this.setState({ username: val, check_textInputChange: true, isValidUser: true });
    }
    else {
      this.setState({ username: val, check_textInputChange: false, isValidUser: false });
    }
  }

  handlePasswordChange = (val) => {
    if (val.trim().length >= 8) {
      this.setState({ isValidPassword: true, password: val });
    }
    else {
      this.setState({ isValidPassword: false, password: val });
    }
  }

  updateSecureTextEntry = () => {
    this.setState({ secureTextEntry: !this.state.secureTextEntry });
  }

  handleValidUser = (val) => {
    if (val.trim().length >= 4) {
      this.setState({ isValidUser: true });
    }
    else {
      this.setState({ isValidUser: false });
    }
  }
  async _loadFontsAsync() {
    await Font.loadAsync(customFonts);
    this.setState({ fontsLoaded: true });
  }
 
  onSubmit = async () => {
    try {
      this.setState({ token: "abc123" })
      await AsyncStorage.setItem('token', 'abc123')
      await AsyncStorage.setItem('user_id', this.state.user_id.toString())
      this.setState({ spinner: false })
      this.props.navigation.navigate('OptionMeasurement')
    } catch (err) {
      console.log(err)
    }
  }
  operation() {
    //   if(this.state.username === '' || this.state.username === undefined){
    //     this.setState({ originalview: false })
    //     this.setState({ Toast3: true })
    //     setTimeout(() => {
    //       this.setState({ Toast3: false })
    //       this.setState({ originalview: true })
    //     }, 2000)
    //     // set focus here??
    //     this.compNameInput.focus();
    //     return;
    //  }
    this.setState({ spinner: true })
    this.upload();
  }
 
  upload = async () => {
    // Check if any file is selected or not
    if (this.state.username != null && this.state.password != null) {
      // If file selected then create FormData
      var data = this.createFormData({
        username: this.state.username,
        password: this.state.password,
      });
      // fetch("http://34.133.197.208:8005/login_API/", {
      fetch("http://15.185.198.78:8002/login_API/", {

        method: "POST",
        body: data
      })
        .then(response => response.json())
        .then(response => {
          console.log("Upload Success", response);
          this.setState({ user_id: response.user_id })
          if (response.status == false) {
            this.setState({ spinner: false })
            this.setState({ originalview: false })
            this.setState({ Toast1: true })
            setTimeout(() => {
              this.setState({ Toast1: false })
              this.setState({ originalview: true })
            }, 2000)
          }
          else {
           
            this.onSubmit();
          }
        })
        .catch(error => {
          console.log("upload error", error);
          this.setState({ spinner: false })
          this.setState({ originalview: false })
          this.setState({ Toast2: true })
          setTimeout(() => {
            this.setState({ Toast2: false })
            this.setState({ originalview: true })
          }, 2000)
        })
    }
    else {
      // If no file selected the show alert
      this.setState({ spinner: false })
      this.setState({ originalview: false })
      this.setState({ Toast: true })
      setTimeout(() => {
        this.setState({ Toast: false })
        this.setState({ originalview: true })
      }, 2000)

    }
  };
  createFormData = (body) => {
    const data = new FormData();
    Object.keys(body).forEach(key => {
      data.append(key, body[key]);
    });
    console.log(data);
    return data;
  };
  componentDidMount() {
    this._loadFontsAsync();
    BackHandler.addEventListener("hardwareBackPress", this.backAction);
  }
  componentWillUnmount() {
    BackHandler.removeEventListener("hardwareBackPress", this.backAction);
  }
  render() {
    if (this.state.fontsLoaded) {
      return (
        <ScrollView keyboardShouldPersistTaps='handled' contentContainerStyle={{ flexGrow: 1, }}>
          <ImageBackground source={require('./assets/kandora1.jpg')} style={styles.container}>
            {
              this.state.spinner ?
                <Spinner
                  visible={true}
                  textContent={'Loading...'}
                  textStyle={styles.spinnerTextStyle} />
                :
                null
            }
            <TouchableOpacity onPress={() => this.props.navigation.goBack()} style={{}}>
              <Image source={require('./assets/arrowpng.png')} style={styles.logo} />
            </TouchableOpacity>
            <View style={{
              flex: 0.4, width: '80%', backgroundColor: "#fff", marginBottom: 35,
              marginTop: 90, borderColor: '#7a42f4', borderWidth: 1, borderRadius: 13
            }}>
              <ScrollView keyboardShouldPersistTaps='handled' contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', }} >
                <Text style={{ fontSize: 18, margin: 10, fontFamily: 'hambold' }}>LOGIN TO YOUR ACCOUNT</Text>
                <Text style={styles.textstyle}>ENTER USERNAME</Text>
                <View style={[styles.input, { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: 2 }]}>
                  <FontAwesome name="user-o" color={"#000"} size={20} />
                  <TextInput

                    placeholder="Your Username"
                    placeholderTextColor="#666666"
                    style={[styles.textInput, { color: "#000" }]}
                    autoCapitalize="none"
                    onChangeText={(val) => this.textInputChange(val)}
                    onEndEditing={(e) => this.handleValidUser(e.nativeEvent.text)}
                    ref={(input) => { this.compNameInput = input; }}
                  // style={styles.input}
                  // placeholder="Enter your username"
                  // placeholderTextColor="#c7c7c7"
                  // onChangeText={(username) => this.setState({ username })}
                  // value={this.state.username}
                  // autoCapitalize="none"
                  />
                  {
                    this.state.check_textInputChange ?
                      <Animatable.View animation="bounceIn" style={{ marginRight: 15 }} >
                        <Feather
                          name="check-circle"
                          color="#000"
                          size={20}
                        />
                      </Animatable.View>
                      : null
                  }
                </View>
                <View style={{ justifyContent: 'flex-start', marginBottom: 5 }}>

                  {
                    this.state.isValidUser ? null :

                      <Animatable.View animation="fadeInLeft" duration={500} style={{ marginLeft: 10 }}>
                        <Text style={styles.errorMsg}>Username must be 4 characters long.</Text>
                      </Animatable.View>


                  }
                </View>

                {/* <TextInput style={styles.Input}
                  placeholder=""
                  placeholderTextColor='#B8B3B3'
                  onChangeText={(username) => this.setState({ username })}
                  value={this.state.username}
                  autoCapitalize="none"
                /> */}
                <Text style={styles.textstyle}>PASSWORD</Text>


                <View style={[styles.input, { flexDirection: 'row', alignItems: 'center' }]}>
                  <Feather name="lock" color={"#000"} size={20} />
                  <TextInput
                    placeholder="Your Password"
                    placeholderTextColor="#666666"
                    secureTextEntry={this.state.secureTextEntry ? true : false}
                    style={[styles.textInput, { color: "#000" }]}
                    autoCapitalize="none"
                    onChangeText={(val) => this.handlePasswordChange(val)}

                  // style={styles.input}
                  // placeholder="Enter your password"
                  // placeholderTextColor="#c7c7c7"
                  // onChangeText={(password) => this.setState({ password })}
                  // value={this.state.password}
                  // autoCapitalize="none"
                  // secureTextEntry
                  />



                  <TouchableOpacity onPress={this.updateSecureTextEntry} style={{ marginRight: 15 }} >
                    {
                      this.state.secureTextEntry ?
                        <Feather name="eye-off" color="grey" size={20} />
                        :
                        <Feather name="eye" color="grey" size={20} />
                    }
                  </TouchableOpacity>



                </View>

                {
                  this.state.isValidPassword ?
                    null :
                    <Animatable.View animation="fadeInLeft" duration={500} style={{ marginLeft: 10 }}>
                      <Text style={styles.errorMsg}>Password must be 8 characters long.</Text>
                    </Animatable.View>
                }
                {/* <TextInput style={styles.Input}
                  placeholder=""
                  placeholderTextColor='#B8B3B3'
                  secureTextEntry
                  onChangeText={(password) => this.setState({ password })}
                  value={this.state.password}
                  autoCapitalize="none"
                /> */}
                <Text style={{ color: "#181b51", textAlign: 'right', margin: 10, fontSize: 15, fontFamily: 'hamextrabold' }}>Forgot Password ?</Text>
                <TouchableOpacity style={{ backgroundColor: "#181b51", margin: 5, borderRadius: 100 }}
                  onPress={() => this.operation()}
                // onPress={() => { this.props.navigation.navigate('OptionMeasurement') }}
                >
                  <Text style={{ fontSize: 18, color: '#fff', padding: 10, textAlign: 'center', fontFamily: 'hamextrabold' }}>LOGIN</Text>
                </TouchableOpacity>
                <Text style={{ fontSize: 20, textAlign: 'center', marginTop: 30, fontFamily: 'hamextrabold' }}>-------- or -------</Text>
              </ScrollView>
            </View>
            {
              this.state.originalview ?
                <View style={{
                  flex: 0.1, justifyContent: 'center', alignItems: 'center', backgroundColor: "#fff", marginBottom: 7
                  , borderColor: "#181b51", borderRadius: 100, borderWidth: 1
                }}>
                  <TouchableOpacity
                    onPress={() => { this.props.navigation.navigate('Register') }}
                  >
                    <Text style={{ fontSize: 18, color: '#181b51', padding: 5, paddingLeft: 50, paddingRight: 50, fontFamily: 'hamextrabold' }}>
                      CREATE AN ACCOUNT
                    </Text>
                  </TouchableOpacity>
                </View>
                :
                null
            }


          </ImageBackground>
          {
            this.state.Toast ?
              <View style={{
                flex: 0.1, backgroundColor: "#0000d8",
                // borderTopLeftRadius: 30, borderTopRightRadius: 30 
              }}>
                <Text style={{ color: "#fff", padding: 15 }}>please enter username and password</Text>
              </View>
              :
              null
          }
          {
            this.state.Toast1 ?
              <View style={{
                flex: 0.1, backgroundColor: "#0000d8",
                // borderTopLeftRadius: 30, borderTopRightRadius: 30 
              }}>
                <Text style={{ color: "#fff", padding: 15 }}>Invalid username or password</Text>
              </View>
              :
              null
          }
          {
            this.state.Toast2 ?
              <View style={{
                flex: 0.1, backgroundColor: "#0000d8",
                // borderTopLeftRadius: 30, borderTopRightRadius: 30 
              }}>
                <Text style={{ color: "#fff", padding: 15 }}>Try Again...</Text>
              </View>
              :
              null
          }
        </ScrollView>
      )
    }
    else {
      return <AppLoading />;
    }
  }
}
const styles = StyleSheet.create(
  {
    container: {
      flex: 1,
      width: null,
      height: null,
      justifyContent: 'center',
      alignItems: 'center'

    },
    logo: {
      width: 60,
      height: 60,
      marginRight: 250,
      marginTop: 15
    },
    spinnerTextStyle: {
      color: '#FFF'
    },
    errorMsg: {
      color: '#FF0000',
      fontSize: 14,
    },
    input: {
      width: WIDTH - 90,
      height: 35,
      marginLeft: 5,
      fontSize: 12,
      marginTop: 10,
      marginBottom: 10,
      paddingLeft: 10,
      backgroundColor: "#fff",
      borderRadius: 10,
      borderColor: '#7a42f4',
      borderWidth: 1
    },
    Input: {
      width: WIDTH - 90,
      marginLeft: 5,
      height: 35,
      marginTop: 10,
      marginBottom: 10,
      borderRadius: 10,
      paddingLeft: 5
      , fontFamily: 'hamextrabold',
      borderColor: '#7a42f4',
      borderWidth: 1
    },
    textInput: {
      flex: 1,
      marginTop: Platform.OS === 'ios' ? 0 : -12,
      paddingLeft: 10,
      color: '#05375a',
    },
    textstyle: {
      marginLeft: 5,
      fontSize: 13,
      // marginTop: 5,
      fontFamily: 'hamextrabold'
    }
  }
)
export default LogIn;