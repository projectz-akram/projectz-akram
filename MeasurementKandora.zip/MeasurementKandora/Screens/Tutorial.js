import * as React from 'react';
import { View, StyleSheet, Button, Text,TouchableOpacity,Image } from 'react-native';
import { Video, AVPlaybackStatus } from 'expo-av';

export default function Tutorial(props) {
  const video = React.useRef(null);
  const video2 = React.useRef(null);

  const uri = "http://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4"


  const [status, setStatus] = React.useState({});
  const [status2, setStatus2] = React.useState({});
  const [currentVideo, setCurrentVideo] = React.useState(0);

  React.useEffect(() => {
    const unsubscribe = props.navigation.addListener('blur', async e => {
      await video.current.stopAsync();
      await video2.current.stopAsync();
    })

    return unsubscribe;
  })


  const handleStatusUpdate = (index, status) => {
    if (status.isPlaying) {
      setCurrentVideo(index);
      if (index == 0) setStatus(status); else setStatus2(status);
    }
  }

  React.useEffect(() => {
    (async () => {
      if (currentVideo == 0 && status2.isPlaying) {
        await video2.current.stopAsync()
      } else if (currentVideo == 1 && status.isPlaying) {
        await video.current.stopAsync();
      }
    })()
  }, [currentVideo])


  return (
    <View style={styles.container}>
      <View style={{ flex: 0.25, backgroundColor: "#181b51" }}>
        <View style={{ flexDirection: 'row', marginTop: 5, marginLeft: 5 }}>
          <TouchableOpacity onPress={() => props.navigation.goBack()} style={{ alignItems: "flex-start", marginTop: 10 }}>
            <Image source={require('./assets/arrowpng.png')}
              resizeMode="contain"
              style={styles.logo} />
          </TouchableOpacity>
          <Text style={{ fontSize: 15, color: "#fff", alignItems: 'center', marginTop: 18, marginLeft: 60,}}>Videos</Text>
        </View>
      </View>
      <View style={{ flex: 1, backgroundColor: "#181b51" }}>

        <Video
          ref={video}
          style={styles.video}
          source={{ uri }}
          useNativeControls
          resizeMode="cover"
          isLooping
          onPlaybackStatusUpdate={status => handleStatusUpdate(0, status)}
        />
        <Text style={{ fontSize: 20, textAlign: 'center', marginBottom: 10, marginTop: 10, margin: 20, color: "#fff" }}>Back camera measurement</Text>


      </View>
      <View style={{ flex: 1, backgroundColor: "#181b51" }}>
        <Video
          ref={video2}
          style={styles.video}
          source={{ uri }}
          useNativeControls
          resizeMode="cover"
          isLooping
          onPlaybackStatusUpdate={status => handleStatusUpdate(1, status)}
        />
        <Text style={{ fontSize: 20, textAlign: 'center', marginBottom: 10, marginTop: 10, color: "#fff" }}>Front camera measurement</Text>

      </View>

      {/* <View style={styles.buttons}>
        <Button
          title={status.isPlaying ? 'Pause' : 'Play'}
          onPress={() =>
            status.isPlaying ? video.current.pauseAsync() : video.current.playAsync()
          }
        />
      </View> */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
  },
  video: {
    alignSelf: 'center',
    marginTop: 10,
    width: 350,
    height: 200,

  },
  logo: {
    width: 80,
    height: 40,
    tintColor: "#fff"

},
  buttons: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
});