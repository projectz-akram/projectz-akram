import * as tf from '@tensorflow/tfjs';
import '@tensorflow/tfjs-react-native';
import * as posenet from '@tensorflow-models/posenet';
import React, { useState, useEffect } from 'react';
import * as jpeg from 'jpeg-js';
import * as FileSystem from 'expo-file-system';
import { FontAwesome, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Permissions from 'expo-permissions';
import { GLView } from 'expo-gl';
import * as ImageManipulator from "expo-image-manipulator";
import * as ScreenOrientation from 'expo-screen-orientation';
import { contextCreate, renderPoints, clearWebGLBuffer } from './gl';
import { StyleSheet, Text, View, Image, TouchableOpacity, ActivityIndicator, Platform, Dimensions, SafeAreaView, Animated } from 'react-native';
import { Camera } from 'expo-camera';
const { width, height } = Dimensions.get('window');
import { CountdownCircleTimer } from 'react-native-countdown-circle-timer'
import { or } from 'react-native-reanimated';
// import Audio1 from "./Audio1"
class SelectMeasurement extends React.Component {
  constructor() {
    super()
    this.state = {
      type: Camera.Constants.Type.back,
      loader: false,
      pic: true,
      text: true,
      front: null,
      side: null,
      height: null,
      imageResult1: null,
      imageResult2: null,
      isRatioSet: false,
      imagePadding: 0,
      ratio: '4:3',
      flip: true,
      wait: false,
      camerascreen: true,
      message: true,
      line: false,
      net: null,
      humanpic: null,
      isPosenetLoaded: false,
      nose: null,
      shulder_left: null,
      hip_left: null,
      knee_left: null,
      ankle_left: null,
      shulder_right: null,
      hip_right: null,
      knee_right: null,
      ankle_right: null,
      counter: 0,
      NoHuman: false,
      closedinterval: false
    }
  }
  prepareRatio = async () => {
    let desiredRatio = '4:3';
    let screenRatio = height / width;
    if (Platform.OS === 'android') {
      const ratios = await this.camera.getSupportedRatiosAsync();
      let distances = {};
      let realRatios = {};
      let minDistance = null;
      for (const ratio of ratios) {
        const parts = ratio.split(':');
        const realRatio = parseInt(parts[0]) / parseInt(parts[1]);
        realRatios[ratio] = realRatio;
        const distance = screenRatio - realRatio;
        distances[ratio] = realRatio;
        if (minDistance == null) {
          minDistance = ratio;
        } else {
          if (distance >= 0 && distance < distances[minDistance]) {
            minDistance = ratio;
          }
        }
      }
      desiredRatio = minDistance;
      const remainder = Math.floor(
        (height - realRatios[desiredRatio] * width) / 2
      );
      this.setState({ imagePadding: remainder / 2, ratio: desiredRatio, isRatioSet: true })
    }
  };
  setCameraReady = async () => {
    if (!this.state.isRatioSet) {
      await this.prepareRatio();
    }
  };
  snap1 = async () => {
    if (this.camera) {
      this.setState({ loader: !this.state.loader })
      let photo1 = await this.camera.takePictureAsync();
      // setTimeout(() => {
      if (photo1 != null) {
        // this.setState({ loader: !this.state.loader })
        this.setState({ side: photo1.uri })
        this.setState({ imageResult2: photo1 })
        this.setState({ flip: !this.state.flip })
        this.setState({ camerascreen: !this.state.camerascreen })
        setTimeout(() => {
          this.setState({ loader: !this.state.loader })
          this.setState({ wait: !this.state.wait })
          this.uploadImage();
        }, 50);
      }
      console.log("akram", photo1)
    }
  };
  snap = async () => {
    if (this.camera) {
      let photo = await this.camera.takePictureAsync();
      console.log(photo)
      if (photo != null) {
        this.setState({ front: photo.uri })
        this.setState({ imageResult1: photo })
        this.setState({ loader: !this.state.loader })
        this.setState({ pic: !this.state.pic })
        this.setState({ text: !this.state.text })
        this.setState({ loader: !this.state.loader })
        setTimeout(() => {
          this.snap1();
        }, 9500);
      }
    }
  }
  Humandetect = async () => {
    if (this.camera) {
      let photo = await this.camera.takePictureAsync();
      if (photo != null) {
        this.setState({ front: photo.uri })
        this.setState({ imageResult1: photo })
        console.log("image", photo.uri);
        const resize = 0.05;
        const manipResult = await ImageManipulator.manipulateAsync(
          photo.uri,
          [{ resize: { width: photo.width * resize, height: photo.height * resize } }],
          { compress: 0.7, format: ImageManipulator.SaveFormat.JPEG }
        );
        const imgB64 = await FileSystem.readAsStringAsync(manipResult.uri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        const imgBuffer = tf.util.encodeString(imgB64, 'base64').buffer;
        const rawImageData = new Uint8Array(imgBuffer);
        const TO_UINT8ARRAY = true;
        const { width, height, data } = jpeg.decode(rawImageData, TO_UINT8ARRAY);
        const image = { data: data, width: width, height: height };
        this.getPoseFromPhoto(image);
      }
    }
  }
  getPoseFromPhoto = async (image) => {
    let net = this.state.net;
    if (net) {
      const pose = await net.estimateSinglePose(image, {
        flipHorizontal: this.state.cameraType === this.state.type
      });
      const imageW = image.width;
      const imageH = image.height;
      let keypoints = pose['keypoints'];
      let points = [];
      keypoints.forEach(key => {
        if (key['part'] == 'nose') {
          this.state.nose = key['position'].y
        }
        if (key['part'] == 'leftShoulder') {
          this.state.shulder_left = key['position'].y
        }
        if (key['part'] == 'leftHip') {
          this.state.hip_left = key['position'].y
        }
        if (key['part'] == 'leftKnee') {
          this.state.knee_left = key['position'].y
        }
        if (key['part'] == 'leftAnkle') {
          this.state.ankle_left = key['position'].y
        }
        if (key['part'] == 'rightShoulder') {
          this.state.shulder_right = key['position'].y
        }
        if (key['part'] == 'rightHip') {
          this.state.hip_right = key['position'].y
        }
        if (key['part'] == 'rightKnee') {
          this.state.knee_right = key['position'].y
        }
        if (key['part'] == 'rightAnkle') {
          this.state.ankle_right = key['position'].y
        }
        let position = key['position'];
        points.push((position.x / imageW) * 2.0 - 1.0);
        points.push(((imageH - position.y) / imageH) * 2.0 - 1.0);
        points.push(0.0);
      });
      console.log(this.state.nose, 'nose\n')
      console.log(this.state.shulder_left, "left shoulder")
      console.log(this.state.hip_left, 'left hip')
      console.log(this.state.knee_left, 'left knee')
      console.log(this.state.ankle_left, 'left ankle\n')
      console.log(this.state.shulder_right, 'rightShoulder')
      console.log(this.state.hip_right, 'rightHip')
      console.log(this.state.knee_right, 'rightKnee')
      console.log(this.state.ankle_right, 'right ankle\n')
      if (
        ((this.state.ankle_left > this.state.knee_left) && (this.state.knee_left > this.state.hip_left) && (this.state.hip_left > this.state.shulder_left) && (this.state.shulder_left > this.state.nose))
        &&
        ((this.state.ankle_right > this.state.knee_right) && (this.state.knee_right > this.state.hip_right) && (this.state.hip_right > this.state.shulder_right) && (this.state.shulder_right > this.state.nose))
      ) {
        this.state.counter += 1;
        // console.log("true")
        console.log(this.state.counter)
      } else {
        console.log("No Humans Detected")
        this.setState({ NoHuman: true })
        // alert("No Humans Detected")
        this.state.counter = 0;
      }
      if (this.state.counter > 0) {
        this.setState({ NoHuman: false })

      }
      if (this.state.counter >= 3) {
        this.setState({ closedinterval: true })
        this.ClearInterval();
        console.log("True! Human Detected...")
        this.state.counter = 0;
        // this.state.humanpic = "true"
        // console.log(this.state.humanpic)
        this.setState({ loader: !this.state.loader })
        setTimeout(() => {
          this.snap();
        }, 6000);
      }
      // renderPoints(points);
      this.forceUpdate();
    }
  }
  clearGLScreen() {
    clearWebGLBuffer();
  }
  componentDidMount = async () => {
    await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT);
    await tf.ready();
    const { status } = await Camera.getPermissionsAsync();
    let finalStatus = status;
    if (status !== 'granted') {
      const { status } = await Camera.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== 'granted') {
      console.log(`camera permission denied`);
    }
    const net = await posenet.load();
    if (net) {
      this.setState({
        isPosenetLoaded: true,
        net: net,
      });
    }
    setTimeout(() => {
      this.setState({ message: !this.state.message })
      // this.setState({ line: !this.state.line })
      // this.setState({ loader: !this.state.loader })
      this.interval = setInterval(() => {
        if (this.state.closedinterval === false) {
          this.Humandetect()
        }
        else {
          this.clearInterval(this.interval)
        }
      }, 5000);
    }, 50);
  }
  ClearInterval = () => {
    clearInterval(this.interval)
  }
  uploadImage = async () => {
    if (this.state.imageResult1 != null && this.state.imageResult2 != null && this.state.height != null) {
      var data = this.createFormData(this.state.imageResult1, this.state.imageResult2, { height: this.state.height });
      fetch("http://15.185.198.78:8002/", {
        method: "POST",
        body: data
      })
        .then(response => response.json())
        .then(response => {
          console.log("Upload Success", response);
          if (response.Status === "please stand infront of camera") {
            alert("please stand infront of camera");
            this.props.navigation.navigate("MeasurementInput")
          }
          else if (response.Status === "ok") {
            this.props.navigation.navigate('ResultScreen', { res: response }
            );
          }
          else if (response.Status === "please enter valid height in centimeters.") {
            alert("please enter valid height in centimeters.");
            this.props.navigation.navigate("MeasurementInput")
          }
          else if (response.Status === "please make sure that images are valid") {
            alert("please make sure that images are valid");
            this.props.navigation.navigate("MeasurementInput")
          }

          else {
            alert("please stand infront of camera");
            this.props.navigation.navigate("MeasurementInput")
          }
        })
        .catch(error => {
          console.error("upload error", error);
          alert("please stand infront of camera");
          this.props.navigation.navigate("MeasurementInput")
        })
    }
    else {
      // If no file selected the show alert
      alert('Please Select any image');
    }
  };
  createFormData = (Front, Side, body) => {
    // createFormData = (Image,body) => {
    const data = new FormData();
    data.append("front", {
      name: "ikram.jpg",
      type: 'image/jpg',
      uri:
        Platform.OS === "android" ? Front.uri : Front.uri.replace("file://", "")
    });
    data.append("side", {
      name: "tayyab.jpg",
      type: "side/jpg",
      uri:
        Platform.OS === "android" ? Side.uri : Side.uri.replace("file://", "")
    });
    Object.keys(body).forEach(key => {
      data.append(key, body[key]);
    });
    console.log(data);
    return data;
  };
  render() {
    const { result } = this.props.route.params
    this.state.height = result
    return (
      <View style={styles.container}>
        <Camera style={[styles.camera_ios, { marginTop: this.state.imagePadding, marginBottom: this.state.imagePadding }]}
          ratio={this.state.ratio}
          useCamera2Api
          onCameraReady={this.setCameraReady}
          ref={ref => {
            this.camera = ref;
          }}
          type={this.state.type}>
          <GLView style={styles.GLContainer} pointerEvents="none"
            onContextCreate={contextCreate}
          // {...this.getPoseFromPhoto()}
          />
          {
            this.state.line ?
              <View style={{
                position: 'absolute', top: 0, left: 0, bottom: 0, width: "50%", backgroundColor: 'rgba(0, 0, 0, 0)',
                borderRightColor: 'green', borderRightWidth: 3,
              }} />
              :
              null
          }
          <View>
            {
              this.state.text ?
                <Text style={{ textAlign: 'center', color: "#000", marginTop: 20, fontSize: 20, backgroundColor: "#fff", fontFamily: 'hamextrabold' }}>Front pose</Text>
                :
                <Text style={{ textAlign: 'center', color: "#000", marginTop: 20, fontSize: 20, backgroundColor: "#fff", fontFamily: 'hamextrabold' }}>Side pose</Text>
            }
          </View>
          {
            this.state.camerascreen ?
              <View style={{
                flex: 1, backgroundColor: "transparent", borderColor: "blue", borderWidth: 1, marginTop: 5, marginLeft: 20, marginRight: 20
              }}>
                {
                  this.state.pic ?
                    <Image source={require('./assets/frontside.png')} style={styles.logo} />
                    :
                    <Image source={require('./assets/sidepose.png')} style={styles.logo} />
                }
                {
                  this.state.loader ?
                    <View style={{ justifyContent: 'center', alignItems: 'center', flexDirection: 'row' }}>
                      <CountdownCircleTimer
                        isPlaying={true}
                        size={100}
                        strokeWidth={12}
                        duration={10}
                        colors={[
                          ['#00D100', 0.8],
                          ['#e6070e', 0.2],
                          // ['red', 0.2],
                        ]}
                        onComplete={() => [true]}
                      >
                        {({ remainingTime, animatedColor }) => (
                          <Animated.Text style={{ color: animatedColor, fontSize: 55 }}>
                            {remainingTime}
                          </Animated.Text>
                        )}
                      </CountdownCircleTimer>
                    </View>
                    :
                    null
                }
                {
                  this.state.message ?
                    <View style={{ flex: 0.75, backgroundColor: "#fff", margin: 25, alignItems: 'center' }}>
                      <Text style={{ fontSize: 17, marginTop: 10, fontFamily: 'hamextrabold' }}>Device Setup</Text>
                      <Text style={{ textAlign: 'justify', margin: 10, fontFamily: 'hamextrabold' }}>Set your device vertically straight between 86% - 90% angle.
                        Please ensure that your device is not tilted to left,right,forward or backward.
                      </Text>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
                        <Image source={require('./assets/directionpic.png')} style={{ width: 95, height: 85 }} />
                        <Image source={require('./assets/directionpic1.png')} style={{ width: 95, height: 85 }} />
                      </View>

                      {/* <View style={{flexDirection:'row'}}>
                        <Audio1/>
                      </View> */}
                    </View>
                    :
                    null
                }
                {
                  this.state.NoHuman ?
                    <View style={{ flex: 0.2, backgroundColor: "#fff", marginTop: 80, margin: 25, alignItems: 'center', justifyContent: 'center' }}>
                      <Text style={{ fontSize: 20 }}>No Humans Detected?</Text>
                    </View>
                    :
                    null
                }
              </View>
              :
              null
          }
          {
            this.state.flip ?
              <View style={styles.buttonContainer}>
                <TouchableOpacity
                  style={styles.button}
                  onPress={() => {
                    if (this.state.type === Camera.Constants.Type.back) {
                      this.setState({ type: Camera.Constants.Type.front });
                    }
                    else {
                      this.setState({ type: Camera.Constants.Type.back });
                    }
                  }}>
                  <Text style={styles.text}> Flip </Text>
                </TouchableOpacity>
              </View>
              :
              null
          }
          {
            this.state.wait ?
              <View style={{
                flex: 1, backgroundColor: "#fff", borderColor: "blue", borderWidth: 1,
                marginTop: 25, marginLeft: 20, marginRight: 20, marginBottom: 25, justifyContent: 'center',
                alignItems: 'center'
              }}
              >
                <Image source={require('./assets/measurement.jpg')}
                  resizeMode="contain"
                  style={{ width: '70%', height: '50%' }} />
                <Text style={{ fontSize: 20, fontFamily: 'hamextrabold' }}>Doing magic....</Text>
                <ActivityIndicator color='red' size={70} />
                <Text style={{ fontFamily: 'hamextrabold' }}>Please Wait....</Text>
                <Text style={{ fontFamily: 'hamextrabold' }}>it can take upto 60 seconds...</Text>
              </View>
              :
              null
          }
        </Camera>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  camera: {
    width: width,
    height: height / 1.15
  },
  camera_ios: {
    flex: 1
  },
  buttonContainer: {
    flex: 0.07,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center'
  },
  button: {
    // flex: 0.1,
    // alignSelf: "flex-end",
    // alignItems: "center",
  },
  text: {
    fontSize: 22,
    color: 'white',
    marginRight: 10,
    marginTop: 10,
    marginBottom: 5
  },
  logo: {
    width: 100,
    height: 130
  }
});
export default SelectMeasurement;