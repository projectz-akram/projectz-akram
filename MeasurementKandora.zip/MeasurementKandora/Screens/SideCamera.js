import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View,Image, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Camera } from 'expo-camera';
import { or } from 'react-native-reanimated';
import { back } from 'react-native/Libraries/Animated/src/Easing';

class SelectMeasurement extends React.Component {
  constructor() {
    super()
    this.state = {
      type: Camera.Constants.Type.back,
      loader: true
    }
  }
  snap = async () => {
    if (this.camera) {
      let photo = await this.camera.takePictureAsync();
      console.log(photo)
     
    }
  };
  componentDidMount() {
      setTimeout(() => {
        this.setState({ loader: !this.state.loader })
        this.snap();
      }, 5000);
  }

  render() {
    return (
      <View style={styles.container}>
        <Camera style={styles.camera} ref={ref => {
          this.camera = ref;
        }} type={this.state.type}
        >
          <Text style={{textAlign:'center',color:"blue",marginTop:20,fontSize:20}}>Front pose</Text>
          <View style={{
            flex: 1, backgroundColor: "transparent", borderColor: "blue", borderWidth: 1, marginTop:5, marginLeft: 20, marginRight:20
          }}>
             <Image source={require('./assets/sidepose.png')} style={styles.logo} />
            {
              this.state.loader ?
                <ActivityIndicator color='#bc2b78' size={70} />
                :
               null
            }
          </View>
          <View style={styles.buttonContainer}>
            
            <TouchableOpacity
              style={styles.button}
              onPress={() => {
                if (this.state.type === Camera.Constants.Type.back) {
                  this.setState({ type: Camera.Constants.Type.front });
                   

                  
                  
                  setTimeout(() => {
                    // this.setState({ loader: !this.state.loader })
                    this.snap();
                  }, 5000);
                 
                }
                else {
                  this.setState({ type: Camera.Constants.Type.back });

                  setTimeout(() => {
                    // this.setState({ loader: !this.state.loader })
                    this.snap();
                  }, 5000);
                }
              }}>
              <Text style={styles.text}> Flip </Text>
            </TouchableOpacity>
          </View>
        </Camera>

  

            
        

       
      </View>
    );

  }
  // const [hasPermission, setHasPermission] = useState(null);
  // const [type, setType] = useState(Camera.Constants.Type.back);
  // const [previewVisible, setPreviewVisible] = useState(false);
  // const [capturedImage, setCapturedImage] = useState(null)

  // useEffect(() => {
  //   (async () => {
  //     const { status } = await Camera.requestPermissionsAsync();
  //     setHasPermission(status === 'granted');
  //   })();
  // }, []);


  // if (hasPermission === null) {
  //   return <View />;
  // }
  // if (hasPermission === false) {
  //   return <Text>No access to camera</Text>;
  // }

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',

  },
  camera: {
    flex: 1,
    
  },
  buttonContainer: {
    flex: 0.07,
    backgroundColor: 'transparent',
   justifyContent:'center',
   alignItems:'center'



  },
  logo: {
    width: 80,
    height: 150,
},
  button: {
    // flex: 0.1,
    // alignSelf: "flex-end",
    // alignItems: "center",
  },
  text: {
    fontSize: 22,
    color: 'white',
    marginRight: 10,
    marginTop: 10,
    marginBottom: 5

  },
});
export default SelectMeasurement;
