/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

 import React from 'react';
 import {
   View,
   Text,
   TextInput,
   StyleSheet,
   ImageBackground,
   Image,
   TouchableOpacity,
   ScrollView,
   StatusBar,
 
   Dimensions
 } from 'react-native';

 const { width: WIDTH } = Dimensions.get('window')
 
 class About extends React.Component {
   render() {
 
     return (
 
       
      
         <View style={{flex:1}}>
           <ScrollView  style={{flex:1,backgroundColor:"#fff"}}>

             <Text>aktghfgfjhfhjgjh</Text>
          <View style={{flex:1,backgroundColor:"#fff",flexDirection:'row'}}>
          <ScrollView horizontal={true}>
          <Text>aktghfgfjhfhjgjh</Text> 
          <Text>aktghfgfjhfhjgjh</Text>
          <Text>aktghfgfjhfhjgjh</Text>
          <Text>aktghfgfjhfhjgjh</Text>
          <Text>aktghfgfjhfhjgjh</Text>
          </ScrollView>

          </View>
            <View style={{backgroundColor:"#000"}}>

            </View>
            </ScrollView>


            </View>
        



         
             
      

         
     )
   }
 }
 const styles = StyleSheet.create(
   {
     container: {
       flex: 1,
       width: null,
       height: null,
 
     },
     logocontainer: {
       flexDirection: 'row',
       alignItems: 'center',
 
     },
     logo: {
       width: 60,
       height: 60,
     },
     logotext: {
       color: "#fff",
       fontSize: 30,
       fontWeight: "500",
     },
     inputcontainer: {
       marginTop: 30,
       shadowOpacity: 1,
       shadowColor: 'red',
       shadowRadius: 10,
       shadowOffset: { width: 0, height: 0 }
 
 
     },
     input: {
       width: WIDTH - 55,
       height: 45,
 
       fontSize: 18,
       paddingLeft: 20,
       backgroundColor: "#fff",
 
     },
     btncontainer: {
       width: WIDTH - 55,
       height: 45,
 
       marginTop: 35,
       backgroundColor: "#232577",
       justifyContent: "center",
     },
     btnText: {
       color: 'rgba(255,255,255,0.7)',
       fontSize: 15,
       textAlign: 'center',
     },
   }
 )
 export default About;