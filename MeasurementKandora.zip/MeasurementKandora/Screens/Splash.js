import React from 'react';
import {
    View,
    StyleSheet,
    Image,
    ActivityIndicator,
    Dimensions
} from 'react-native';
const { width: WIDTH } = Dimensions.get('window')
import AsyncStorage from '@react-native-async-storage/async-storage';
class Splash extends React.Component {
    constructor() {
        super();
        this.state = {
            loader: true
        }
    }
    getData = async () => {
        try {
            const value = await AsyncStorage.getItem('token')
            const user_id = await AsyncStorage.getItem("user_id")
            const email=await AsyncStorage.getItem("email")
            if (value !== null && user_id !== null) {
                console.log(value)
                console.log(user_id)
                console.log(email)
                // this.props.navigation.navigate("LogInScreen")
                this.props.navigation.replace('OptionMeasurement')
            }
            else {
               
                    this.setState({ loader: false })
                    this.props.navigation.replace("Measurement")
              
            }
        } catch (err) {
            console.log(err)
        }
    }
    componentDidMount() {
        setTimeout(() => {
            this.getData()
           
               
           
        }, 4000);
    }
    render() {
        return (
            <View style={{ flex: 1, justifyContent: 'center', backgroundColor: '#181b51' }}>
                <View style={styles.logocontainer} >
                    <Image source={require('./assets/cancanlogow.png')} style={styles.logo} />
                </View>
                {
                    this.state.loader ?
                        <ActivityIndicator color='#bc2b78' size={70} />
                        :
                        <View></View>
                }
            </View>
        );
    }
}
const styles = StyleSheet.create(
    {
        logocontainer: {
            alignItems: 'center',
            justifyContent: 'center'
        },
        logo: {
            width: 210,
            height: 230,
        },
    }
)
export default Splash;