import React from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    Image,
    TouchableOpacity,
    Dimensions,
    ScrollView
} from 'react-native';
const { width: WIDTH } = Dimensions.get('window')
import AppLoading from 'expo-app-loading';
import * as Font from 'expo-font';
import * as ImagePicker from 'expo-image-picker'
import { RotateWithOffset } from '@tensorflow/tfjs';
let customFonts = {
    'Hamelin': require('./assets/fonts/FontsFree-Net-Hamelin.ttf'),
    'caveat': require('./assets/fonts/Caveat-Medium.ttf'),
    'hambold': require('./assets/fonts/Hamlin-Bold.ttf'),
    'hamextrabold': require('./assets/fonts/Hamlin-ExtraBold.ttf'),
    'hamlight': require('./assets/fonts/Hamlin-Light.ttf'),
    'hamregular': require('./assets/fonts/Caveat-Medium.ttf'),
};
class MeasurementInput extends React.Component {
    constructor() {
        super()
        this.state = {
            personal: true,
            stance: false,
            name: null,
            age: null,
            height: null,
            weight: null,

        }
    }
    state = {
        fontsLoaded: false,
    };
    async _loadFontsAsync() {
        await Font.loadAsync(customFonts);
        this.setState({ fontsLoaded: true });
    }
    componentDidMount() {
        this._loadFontsAsync();
    }
    operation1() {
        this.setState({
            personal: true,
            stance: false,
        })
    }
    operation2() {
        this.setState({
            stance: true,
            personal: false,
        })
    }
    Checks() {
        if (this.state.name != null && this.state.age != null && this.state.height != null && this.state.weight != null) {
            this.props.navigation.navigate('SelectMeasurement', { result: this.state.height })
        }
        else {
            alert("Please Enter All Information")
        }
    }
    render() {
        const btncolor1 = this.state.personal ? "#181b51" : "#808080";
        const btncolor2 = this.state.stance ? "#181b51" : "#808080";
        if (this.state.fontsLoaded) {
            return (
                <ScrollView keyboardShouldPersistTaps='handled' contentContainerStyle={{ flexGrow: 1, }}>
                    <ScrollView contentContainerStyle={{ flexGrow: 1, }}>
                        <View style={{ flex: 0.03, backgroundColor: "#181b51" }}>
                            <View style={{ flexDirection: 'row', marginTop: 40, marginLeft: 5 }}>
                                <TouchableOpacity onPress={() => this.props.navigation.goBack()} style={{ alignItems: "flex-start" }}>
                                    <Image source={require('./assets/arrowpng.png')} style={styles.logo} />
                                </TouchableOpacity>
                                <Text style={{ fontSize: 15, color: "#fff", alignItems: 'center', marginLeft: 60, fontFamily: 'hamextrabold' }}>MEASUREMENT</Text>
                            </View>
                            <Text style={{ fontSize: 15, color: '#fff', textAlign: 'center', fontFamily: 'hamextrabold' }}>STEP 1/4: HEIGHT/WEIGHT</Text>
                        </View>
                        <View style={{ flex: 0.97, backgroundColor: "#fff", }}>

                            <View style={{ flex: 0.2, alignItems: 'center' }}>
                                <Text style={{ textAlign: 'center', marginTop: 20, fontSize: 15, fontFamily: 'hamextrabold' }}>Note: Please input the values correctly in order to get  accurate measurements.</Text>

                                <TextInput style={styles.Input}
                                    placeholder="Enter your Name"
                                    placeholderTextColor='#B8B3B3'
                                    onChangeText={(name) => this.setState({ name })}
                                    value={this.state.name}
                                    autoCapitalize="none"
                                />
                                <TextInput style={styles.Input}
                                    placeholder="Enter your age"
                                    placeholderTextColor='#B8B3B3'
                                    onChangeText={(age) => this.setState({ age })}
                                    value={this.state.age}
                                    autoCapitalize="none"
                                />
                                <TextInput style={styles.Input}
                                    placeholder="Enter your Height In Centimeters"
                                    placeholderTextColor='#B8B3B3'
                                    onChangeText={(height) => this.setState({ height })}
                                    value={this.state.height}
                                    autoCapitalize="none"
                                />
                                <TextInput style={styles.Input}
                                    placeholder="Enter your Weight (In kg)"
                                    placeholderTextColor='#B8B3B3'
                                    onChangeText={(weight) => this.setState({ weight })}
                                    value={this.state.weight}
                                    autoCapitalize="none"
                                />



                                


                            </View>
                            <View style={{ flex: 0.2, flexDirection: 'row', justifyContent: 'center' }}>
                                <TouchableOpacity>
                                    <Text onPress={() => this.operation1()} style={{
                                        width: 150, color: "#fff", fontSize: 18, marginTop: 10, marginBottom: 10,
                                        marginRight: 5, textAlign: 'center', fontFamily: 'hamextrabold',
                                        borderRadius: 10, backgroundColor: btncolor1, padding: 5, borderColor: '#7a42f4',
                                        borderWidth: 1
                                    }}>Wearing  the  kandora  </Text>
                                </TouchableOpacity>
                                <TouchableOpacity>
                                    <Text onPress={() => this.operation2()} style={{
                                        width: 150, fontSize: 18, color: "#fff", marginTop: 10, marginBottom: 10,
                                        marginLeft: 5, textAlign: 'center', borderRadius: 10, fontFamily: 'hamextrabold',
                                        backgroundColor: btncolor2, padding: 5, borderColor: '#7a42f4', borderWidth: 1
                                    }}> Wearing Casual Clothes</Text>
                                </TouchableOpacity>


                            </View>


                            {/* <Text style={{ textAlign: 'center', marginTop: 20, marginBottom: 15, fontSize: 15, fontFamily: 'hamextrabold' }}>Note: Please input the values correctly in order to get  accurate measurements.</Text>

                            <TextInput style={styles.Input}
                                placeholder="Enter your Name"
                                placeholderTextColor='#B8B3B3'
                                onChangeText={(name) => this.setState({ name })}
                                value={this.state.name}
                                autoCapitalize="none"
                            />
                            <TextInput style={styles.Input}
                                placeholder="Enter your age"
                                placeholderTextColor='#B8B3B3'
                                onChangeText={(age) => this.setState({ age })}
                                value={this.state.age}
                                autoCapitalize="none"
                            />
                            <TextInput style={styles.Input}
                                placeholder="Enter your Height In feet e.g 5.6"
                                placeholderTextColor='#B8B3B3'
                                onChangeText={(height) => this.setState({ height })}
                                value={this.state.height}
                                autoCapitalize="none"
                            />
                            <TextInput style={styles.Input}
                                placeholder="Enter your Weight (In kg)"
                                placeholderTextColor='#B8B3B3'
                                onChangeText={(weight) => this.setState({ weight })}
                                value={this.state.weight}
                                autoCapitalize="none"
                            />
                            <View style={{ flexDirection: 'row', marginTop: 20, }}>
                                <TouchableOpacity>
                                    <Text onPress={() => this.operation1()} style={{
                                        width: WIDTH - 195, color: "#fff", fontSize: 18, marginTop: 10, marginBottom: 10,
                                        marginRight: 5, textAlign: 'center', fontFamily: 'hamextrabold',
                                        borderRadius: 10, backgroundColor: btncolor1, paddingLeft: 5, borderColor: '#7a42f4',
                                        borderWidth: 1
                                    }}>Wearing  the  kandora  </Text>
                                </TouchableOpacity>
                                <TouchableOpacity>
                                    <Text onPress={() => this.operation2()} style={{
                                        width: WIDTH - 195, fontSize: 18, color: "#fff", marginTop: 10, marginBottom: 10,
                                        marginLeft: 5, textAlign: 'center', borderRadius: 10, fontFamily: 'hamextrabold',
                                        backgroundColor: btncolor2, paddingLeft: 5, borderColor: '#7a42f4', borderWidth: 1
                                    }}> Wearing Casual Clothes</Text>
                                </TouchableOpacity>
                            </View> */}

                        </View>
                    </ScrollView>
                    <View style={{ flex: 0.3, justifyContent: 'center' }}>
                        <TouchableOpacity onPress={() => { this.props.navigation.navigate('Tutorial') }}>
                            <Text style={{ color: "#181b51", textAlign: 'center', fontSize: 18, fontFamily: 'hamextrabold' }}>WATCH TUTORIAL</Text>
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity onPress={() => this.Checks()} style={{ flex: 0.3, backgroundColor: "#181b51", justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ fontSize: 20, color: "#fff", fontFamily: 'hamextrabold' }}>NEXT</Text>
                    </TouchableOpacity>
                </ScrollView>
            )
        }
        else {
            return <AppLoading />;
        }
    }
}
const styles = StyleSheet.create(
    {
        logo: {
            width: 60,
            height: 25,
            tintColor: "#fff"
        },
        Input: {
            width: WIDTH - 30,
            marginLeft: 5,
            height: 50,
            marginTop: 10,
            fontSize: 15,
            marginBottom: 10,
            textAlign: 'center',
            fontFamily: 'hamextrabold',
            borderRadius: 10,
            paddingLeft: 5,
            borderColor: '#7a42f4',
            borderWidth: 1
        },
    }
)
export default MeasurementInput;