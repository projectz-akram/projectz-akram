/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

 import React, { useState, useEffect } from 'react';
 import {
     View,
     Text,
     TextInput,
     StyleSheet,
     Title,
     Caption,
     Paragraph,
     ImageBackground,
     Image,
     TouchableOpacity,
     StatusBar,
     BackHandler,
 
     Dimensions,
     Alert
 } from 'react-native';
 //  const { width: WIDTH } = Dimensions.get('window')
 const vw = Dimensions.get('window').width / 100;
 const vh = Dimensions.get('window').height / 100;
 import { } from '@react-navigation/native'
 import { SafeAreaProvider } from 'react-native-safe-area-context'
 import AsyncStorage from '@react-native-async-storage/async-storage';
 import { DrawerContentScrollView, DrawerItemList, DrawerItem } from '@react-navigation/drawer'
 var username;
 var email
const onLogout = async () => {
    try {
        // this.setState({ token: "" })
        await AsyncStorage.removeItem("token")
        await AsyncStorage.removeItem("user_id")
        await AsyncStorage.removeItem("username")
        // alert("Logout successfully");
        // 
        Alert.alert(
            'Exit App',
            'Do you want to exit?',
            [
                { text: 'No', onPress: () => console.log('Cancel Pressed'), style: 'cancel' },
                { text: 'Yes', onPress: () => BackHandler.exitApp() },
            ],
            { cancelable: false });
    } catch (err) {
        console.log(err)
    }
}
const   getData = async () => {
    try {
        const email1=await AsyncStorage.getItem("email")
        const user=await AsyncStorage.getItem("username")
            email=email1
            console.log("user.............",user)
            username=user
            console.log("user email",email)
            console.log("user name ........",username)
    
    } catch (err) {
        console.log(err)
    }
}
 
 function SideMenu(props) {
    useEffect(() => {
       getData();
        
      });
     return (
         <DrawerContentScrollView {...props}>
             <View style={styles.userInfoSection}>
                 <View style={{ marginTop: 50 }}>
                     {/* <Image source={require('./assets/logobalance.png')} style={styles.logo} /> */}
 
                     <Text style={{textAlign:'center',fontSize:18,fontStyle:"normal",color:"#fff"}}>{username}</Text>
                     <Text  style={{textAlign:'center',color:"#fff"}}>{email}</Text>
                 </View>
 
             </View>
 
 
             <DrawerItemList {...props} />
             <DrawerItem
 
                 label="Logout" onPress={() => onLogout()} />
         </DrawerContentScrollView>
     );
 }
 const styles = StyleSheet.create(
     {
         container: {
             flex: 1,
             width: null,
             height: null,
 
         },
         logocontainer: {
             flexDirection: 'row',
             alignItems: 'center',
 
         },
         logo: {
             width: 60,
             height: 60,
             marginLeft:62,
         
             justifyContent: 'center',
             // marginLeft: 15,
             alignItems: 'center'
         },
         logotext: {
             color: "#fff",
             fontSize: 30,
             fontWeight: "500",
         },
         userInfoSection: {
 
             backgroundColor: '#181b51',
             height:150,
             width:280,
             
             alignItems: 'center'
         },
         inputcontainer: {
             marginTop: 30,
             shadowOpacity: 1,
             shadowColor: 'red',
             shadowRadius: 10,
             shadowOffset: { width: 0, height: 0 }
 
 
         },
         section: {
             flexDirection: 'row',
             alignItems: 'center',
             marginRight: 1.5 * vh,
         },
         row: {
             marginTop: 2 * vh,
             flexDirection: 'row',
             alignItems: 'center',
             paddingLeft: 1 * vh
         },
         // input: {
         //     width: WIDTH - 55,
         //     height: 45,
 
         //     fontSize: 18,
         //     paddingLeft: 20,
         //     backgroundColor: "#fff",
 
         // },
         // btncontainer: {
         //     width: WIDTH - 55,
         //     height: 45,
 
         //     marginTop: 35,
         //     backgroundColor: "#232577",
         //     justifyContent: "center",
         // },
         btnText: {
             color: 'rgba(255,255,255,0.7)',
             fontSize: 15,
             textAlign: 'center',
         },
     }
 )
 
 export default SideMenu;