import React from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    ScrollView,
    Image,
    TouchableOpacity,
    Dimensions,
} from 'react-native';
const { width: WIDTH } = Dimensions.get('window')
import AppLoading from 'expo-app-loading';
import * as Font from 'expo-font';
let customFonts = {
    'Hamelin': require('./assets/fonts/FontsFree-Net-Hamelin.ttf'),
    'caveat': require('./assets/fonts/Caveat-Medium.ttf'),
    'hambold': require('./assets/fonts/Hamlin-Bold.ttf'),
    'hamextrabold': require('./assets/fonts/Hamlin-ExtraBold.ttf'),
    'hamlight': require('./assets/fonts/Hamlin-Light.ttf'),
    'hamregular': require('./assets/fonts/Caveat-Medium.ttf'),
};
class ManualMeasurement extends React.Component {
    constructor() {
        super()
        this.state = {
            personal: true,
            stance: false,
        }
    }
    state = {
        fontsLoaded: false,
    };
    async _loadFontsAsync() {
        await Font.loadAsync(customFonts);
        this.setState({ fontsLoaded: true });
    }
    componentDidMount() {
        this._loadFontsAsync();
    }
    operation1() {
        this.setState({
            personal: true,
            stance: false,
        })
    }
    operation2() {
        this.setState({
            stance: true,
            personal: false,
        })
    }
    render() {
        const btncolor1 = this.state.personal ? "#181b51" : "#808080";
        const btncolor2 = this.state.stance ? "#181b51" : "#808080";
        if (this.state.fontsLoaded) {
            return (
                <View style={{ flex: 1 }}>
                    <View style={{ flex: 0.25, backgroundColor: "#181b51" }}>
                        <View style={{ flexDirection: 'row', marginTop: 30, marginLeft: 5 }}>
                            <TouchableOpacity onPress={() => {this.props.navigation.goBack()}} style={{ alignItems: "flex-start",marginTop:10 }}>
                                <Image source={require('./assets/arrowpng.png')}
                                    resizeMode="contain"
                                    style={styles.logo} />
                            </TouchableOpacity>
                            <Text style={{ fontSize: 15, color: "#fff", alignItems: 'center', marginTop: 18, marginLeft: 60, fontFamily: 'hamextrabold' }}>MEASUREMENTS</Text>
                        </View>
                    </View>
                    <ScrollView style={{ flex: 2.5, }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center',justifyContent:'space-around',marginLeft:40 }}>
                            <TouchableOpacity  onPress={() => this.operation1()} >
                                <Text  style={{
                                    color: "#fff", fontSize: 15, marginTop: 10, marginBottom: 10,
                                       width: "70%", textAlign: 'center', fontFamily: 'hamextrabold', borderRadius: 10, backgroundColor: btncolor1,
                                       paddingLeft: 5, borderColor: '#7a42f4', borderWidth: 1
                                    // width: "70%", color: "#fff", fontSize: 18, marginTop: 10, marginBottom: 10,
                                    // textAlign: 'center', fontFamily: 'hamextrabold', borderRadius: 10, backgroundColor: btncolor1,
                                    // paddingLeft: 5, borderColor: '#7a42f4', borderWidth: 1
                                }}>Wearing  the  kandora  </Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => this.operation2()} >
                                <Text  style={{
                                    color: "#fff", fontSize: 15, marginTop: 10, marginBottom: 10,width: "70%", textAlign: 'center', fontFamily: 'hamextrabold',
                                     borderRadius: 10, backgroundColor: btncolor2,borderColor: '#7a42f4', borderWidth: 1
                                    // width:"70%", fontSize: 18, color: "#fff", marginTop: 10,
                                    // marginBottom: 10, textAlign: 'center', borderRadius: 10, fontFamily: 'hamextrabold',
                                    // backgroundColor: btncolor2, paddingLeft: 5, borderColor: '#7a42f4', borderWidth: 1
                                }}> Wearing Casual Clothes</Text>
                            </TouchableOpacity>
                        </View>
                        <View style={{ flex: 1, backgroundColor: "#fff", }}>
                            <Text style={styles.textstyle}>Shoulder to Shoulder Length in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder=""
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Chest Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder=""
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Biceps Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder=""
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Waist Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder=""
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Arm Length in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder=""
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Shoulder to Feet Length in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder=""
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Wrist Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder=""
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Hips Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder=""
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Neck Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder=""
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                        </View>
                    </ScrollView>
                    <View style={{
                        flex: 0.15, marginTop: 15, borderTopWidth: 1,
                        borderColor: '#000', justifyContent: 'center'
                    }}>
                        <TouchableOpacity onPress={() => { this.props.navigation.navigate('Tutorial') }}>
                            <Text style={{ color: "#181b51", textAlign: 'center', fontSize: 18, fontFamily: 'hamextrabold' }}>WATCH TUTORIAL</Text>
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity
                    //  onPress={() => { this.props.navigation.navigate('SelectMeasurement') }}
                      style={{ flex: 0.1, backgroundColor: "#181b51", justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ fontSize: 20, color: "#fff", fontFamily: 'hamextrabold' }}>Add Measurements </Text>
                    </TouchableOpacity>
                </View>
            )
        }
        else {
            return <AppLoading />;
        }
    }
}
const styles = StyleSheet.create(
    {
        logo: {
            width: 80,
            height: 40,
            tintColor: "#fff"

        },
        Input: {
            width: WIDTH - 50,
            marginLeft: 20,
            height: 50,
            fontSize: 18,
            marginTop: 7,
            fontFamily: 'hamextrabold',
            marginBottom: 7,
            borderRadius: 8,
            paddingLeft: 5,
            borderColor: '#7a42f4',
            borderWidth: 1
        },
        btnText: {
            color: 'rgba(255,255,255,0.7)',
            fontSize: 15,
            textAlign: 'center',
        },
        textstyle: {
            marginLeft: 20,
            fontSize: 16,
            fontFamily: 'hamextrabold',
            marginTop: 5
        },
    }
)
export default ManualMeasurement;