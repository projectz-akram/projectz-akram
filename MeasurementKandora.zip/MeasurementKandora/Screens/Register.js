import React from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    Image,
    TouchableOpacity,
    Dimensions,
    ScrollView
} from 'react-native';
const { width: WIDTH } = Dimensions.get('window')
import AppLoading from 'expo-app-loading';
import Spinner from 'react-native-loading-spinner-overlay';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Font from 'expo-font';
let customFonts = {
    'Hamelin': require('./assets/fonts/FontsFree-Net-Hamelin.ttf'),
    'caveat': require('./assets/fonts/Caveat-Medium.ttf'),
    'hambold': require('./assets/fonts/Hamlin-Bold.ttf'),
    'hamextrabold': require('./assets/fonts/Hamlin-ExtraBold.ttf'),
    'hamlight': require('./assets/fonts/Hamlin-Light.ttf'),
    'hamregular': require('./assets/fonts/Caveat-Medium.ttf'),
};
class Register extends React.Component {
    constructor() {
        super()
        this.state = {
            username: null,
            first_name: null,
            last_name: null,
            email: null,
            phone_number: null,
            password1: null,
            password2: null,
            fontsLoaded: false,
            spinner: false,
            originalview: true,
            Toast: false,
            toastmessage: "",
        }
    }

    onSubmit = async () => {
        try {
         
         
        
          await AsyncStorage.setItem('email', this.state.email.toString())
          this.setState({ spinner: false })
          this.props.navigation.navigate('OptionMeasurement')
        } catch (err) {
          console.log(err)
        }
      }

    async _loadFontsAsync() {
        await Font.loadAsync(customFonts);
        this.setState({ fontsLoaded: true });
    }
    componentDidMount() {
        this._loadFontsAsync();
    }
    upload = async () => {
        // Check if any file is selected or not
        this.setState({ spinner: true })
        if (this.state.username != null &&
            // this.state.first_name != null && this.state.last_name != null && 
            this.state.email != null &&
            // this.state.birth_date !=null&& 
            this.state.password1 != null
            && this.state.password2 != null) {
            // If file selected then create FormData
            var data = this.createFormData({
                username: this.state.username,
                // first_name: this.state.first_name,last_name:this.state.last_name,birth_date:this.state.birth_date,
                email: this.state.email, password1: this.state.password1, password2: this.state.password2
            });
            fetch("http://15.185.198.78:8002/signup_API/", {
                method: "POST",
                body: data
            })
                .then(response => response.json())
                .then(response => {
                    console.log("Upload Success", response);
                    //    this.Authentication(response)

                    // console.log(response.errors);
                    if (response.errors === 'undefined') {
                        alert("Register successfully");
                        this.setState({ spinner: false })
                        AsyncStorage.setItem('email', this.state.email.toString())
                        this.props.navigation.navigate("LogIn");
                        console.log("akram")
                        return true
                    }
                    if (response.errors === undefined) {
                        // alert("Register successfully");
                        this.setState({ spinner: false })
                        this.setState({toastmessage:"Register successfully"})
                        console.log("akram1223")
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                            AsyncStorage.setItem('email', this.state.email.toString())
                            this.props.navigation.navigate("LogIn");
                        }, 2000)
                        return true
                    }
                    if (response.errors.username == "A user with that username already exists.") {
                        this.setState({ spinner: false })
                       this.setState({toastmessage:"A user with that username already exists."})
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                        }, 2000)
                    }
                    else if (response.errors.username == "Enter a valid username. This value may contain only letters, numbers, and @/./+/-/_ characters.") {
                        this.setState({ spinner: false })
                        this.setState({toastmessage:"Enter a valid username. This value may contain only letters, numbers, and @/./+/-/_ characters."})
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                        }, 2000)
                    }
                    else if (response.errors.username != null) {
                        this.setState({ spinner: false })
                        this.setState({toastmessage:"Ensure that username at most 30 characters"})
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                        }, 2000)
                    }
                    else if (response.errors.email == "Enter a valid email address.") {
                        this.setState({ spinner: false })
                        this.setState({toastmessage:"Enter a valid email address."})
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                        }, 2000)
                    }
                    else if (response.errors.password2 == "The two password fields didn’t match.") {
                        this.setState({ spinner: false })
                        this.setState({toastmessage:"The two password fields didn’t match"})
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                        }, 2000)
                    }
                    else if (response.errors.password2 == "The password is too similar to the email address.") {
                        this.setState({ spinner: false })
                        this.setState({toastmessage:"The password is too similar to the email address."})
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                        }, 2000)
                    }
                    else if (response.errors.password2 == "The password is too similar to the username.") {
                        this.setState({ spinner: false })
                        this.setState({toastmessage:"The password is too similar to the username."})
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                        }, 2000)
                    }

                    else if (response.errors.password2 != null) {
                        this.setState({ spinner: false })
                        this.setState({toastmessage:"This password is too short. It must contain at least 8 characters or This password is entirely numeric."})
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                        }, 2000)
                    }
                    else if (response.status === true) {
                        this.setState({toastmessage:"Register successfully"});
                        this.setState({ spinner: false })
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                            AsyncStorage.setItem('email', this.state.email.toString())
                            this.props.navigation.navigate("LogIn");
                        }, 2000)
                       
                    }
                    else {

                        this.setState({toastmessage:"please provide all values"})
                        this.setState({ originalview: false })
                        this.setState({ Toast: true })
                        setTimeout(() => {
                            this.setState({ Toast: false })
                            this.setState({ originalview: true })
                        }, 2000)
                    }

                })
                .catch(error => {
                    console.log("upload error", error);
                    this.setState({ spinner: false })
                    this.setState({toastmessage:"Try Again..."});
                    this.setState({ originalview: false })
                    this.setState({ Toast: true })
                    setTimeout(() => {
                        this.setState({ Toast: false })
                        this.setState({ originalview: true })
                    }, 2000)
                })
        }
        else {
            // If no file selected the show alert
            this.setState({ spinner: false })
            this.setState({ toastmessage: "please provide all values" })
            this.setState({ originalview: false })
            this.setState({ Toast: true })
            setTimeout(() => {
                this.setState({ Toast: false })
                this.setState({ originalview: true })
            }, 2000)

        }
    };
    createFormData = (body) => {
        const data = new FormData();
        Object.keys(body).forEach(key => {
            data.append(key, body[key]);
        });
        console.log(data);
        return data;
    };
    render() {
        if (this.state.fontsLoaded) {
            return (
                <View style={{ flex: 1, backgroundColor: "#181b51" }}>
                    {
                        this.state.spinner ?
                            <Spinner
                                visible={true}
                                textContent={'Loading...'}
                                textStyle={styles.spinnerTextStyle} />
                            :
                            null
                    }
                    <View style={{ flex: 0.6, backgroundColor: "#181b51", margin: 1, marginTop: 22, marginLeft: 10 }}>
                        <View style={{ flex: 1, width: null, height: null, justifyContent: 'center', }}>
                            <TouchableOpacity onPress={() => this.props.navigation.goBack()} style={{ marginBottom: 15 }}>
                                <Image source={require('./assets/arrowpng.png')} style={styles.logo} />
                            </TouchableOpacity>
                            <Text style={{ color: '#fff', fontSize: 20, marginBottom: 10, fontFamily: 'hamextrabold' }}>CREATE AN ACCOUNT</Text>
                        </View>
                    </View>
                    <View style={{ flex: 3, backgroundColor: "#fff", margin: 1, justifyContent: 'center' }}>
                        <ScrollView>
                            <Text style={styles.textstyle}>USERNAME</Text>
                            <TextInput style={styles.Input}
                                placeholder="Enter username"
                                placeholderTextColor='#B8B3B3'
                                onChangeText={(username) => this.setState({ username })}
                                value={this.state.username}
                                autoCapitalize="none"
                            />
                            {/* <Text style={styles.textstyle}>LAST NAME</Text>
                            <TextInput style={styles.Input}
                                placeholder="Enter your last name"
                                placeholderTextColor='#B8B3B3'
                                onChangeText={(last_name) => this.setState({ last_name })}
                                value={this.state.last_name}
                                autoCapitalize="none"
                            /> */}
                            <Text style={styles.textstyle}>EMAIL</Text>
                            <TextInput style={styles.Input}
                                placeholder="Enter your email"
                                placeholderTextColor='#B8B3B3'
                                onChangeText={(email) => this.setState({ email })}
                                value={this.state.email}
                                autoCapitalize="none"
                            />
                            {/* <Text style={styles.textstyle}>PHONE NUMBER</Text>
                            <TextInput style={styles.Input}
                                placeholder="Enter your phone number"
                                placeholderTextColor='#B8B3B3'
                                onChangeText={(phone_number) => this.setState({ phone_number })}
                                value={this.state.phone_number}
                                autoCapitalize="none"
                            /> */}
                            <Text style={styles.textstyle}>PASSWORD</Text>
                            <TextInput style={styles.Input}
                                placeholder="Enter your password"
                                placeholderTextColor='#B8B3B3'
                                secureTextEntry
                                onChangeText={(password1) => this.setState({ password1 })}
                                value={this.state.password1}
                                autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>CONFIRM PASSWORD</Text>
                            <TextInput style={styles.Input}
                                placeholder="Enter your confirm password"
                                secureTextEntry
                                placeholderTextColor='#B8B3B3'
                                onChangeText={(password2) => this.setState({ password2 })}
                                value={this.state.password2}
                                autoCapitalize="none"
                            />
                        </ScrollView>
                    </View>
                    {
                        this.state.originalview ?
                            <View style={{ flex: 0.3, backgroundColor: "#181b51", margin: 1, justifyContent: 'center', alignItems: 'center' }}>
                                <TouchableOpacity
                                    onPress={() => this.upload()}>
                                    <Text style={{ fontSize: 18, color: '#fff', padding: 10, paddingLeft: 50, paddingRight: 50, fontFamily: 'hamextrabold' }}>REGISTER NOW</Text>
                                </TouchableOpacity>
                            </View>
                            :
                            null
                    }

                    {
                        this.state.Toast ?
                            <View style={{
                                flex: 0.4, backgroundColor: "#0000d8",
                                // borderTopLeftRadius: 30, borderTopRightRadius: 30 
                            }}>
                                <Text style={{ color: "#fff", padding: 15 }}>{this.state.toastmessage}</Text>
                            </View>
                            :
                            null
                    }
                </View>
            )
        }
        else {
            return <AppLoading />;
        }
    }
}
const styles = StyleSheet.create(
    {
        logo: {
            width: 60,
            height: 28,
            tintColor: '#fff'
        },
        Input: {
            width: WIDTH - 50,
            marginLeft: 20,
            height: 40,
            fontSize: 15,
            marginTop: 7,
            fontFamily: 'hamextrabold',
            marginBottom: 7,
            borderRadius: 13,
            paddingLeft: 5,
            borderColor: '#7a42f4',
            borderWidth: 1
        },
        spinnerTextStyle: {
            color: '#FFF'
        },
        textstyle: {
            marginLeft: 20,
            fontSize: 15,
            fontFamily: 'hamextrabold',
            marginTop: 5
        }

    }
)
export default Register;