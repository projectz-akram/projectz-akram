import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    Dimensions,
    StatusBar
} from 'react-native';
const { width: WIDTH } = Dimensions.get('window')
import AppLoading from 'expo-app-loading';
import * as Font from 'expo-font';
let customFonts = {
    'Hamelin': require('./assets/fonts/FontsFree-Net-Hamelin.ttf'),
    'caveat': require('./assets/fonts/Caveat-Medium.ttf'),
    'hambold': require('./assets/fonts/Hamlin-Bold.ttf'),
    'hamextrabold': require('./assets/fonts/Hamlin-ExtraBold.ttf'),
    'hamlight': require('./assets/fonts/Hamlin-Light.ttf'),
    'hamregular': require('./assets/fonts/Caveat-Medium.ttf'),
};
class OptionMeasurement extends React.Component {
    constructor() {
        super()
        this.state = {
            option: false,
            addbtn: true,
        }
    }
    state = {
        fontsLoaded: false,
    };
    async _loadFontsAsync() {
        await Font.loadAsync(customFonts);
        this.setState({ fontsLoaded: true });
    }
    componentDidMount() {
        this._loadFontsAsync();
        this._unsubscribe = this.props.navigation.addListener('focus', () => {
            this.setState({
                option: false,
                addbtn: true,
            })
        });
    }
    componentWillUnmount() {
        this._unsubscribe();
    }
    Option() {
        this.setState({
            option: true,
            addbtn: false,
        })
    }
    addbtn() {
        this.setState({
            option: false,
            addbtn: true
        })
    }
    render() {
        const btncolor1 = this.state.personal ? "#181b51" : "#808080";
        const btncolor2 = this.state.stance ? "#181b51" : "#808080";
        if (this.state.fontsLoaded) {
            return (
                <View style={{ flex: 1 }}>
                     <StatusBar
                    backgroundColor="#181b51"
                   
                />
                    {/* <View style={{ flex: 0.15, backgroundColor: "#181b51", flexDirection: 'row', }}>
                        <TouchableOpacity onPress={() => this.props.navigation.goBack()} style={{
                            alignItems: "flex-start",
                            marginLeft: 15, marginTop: 45
                        }}>
                            <Image source={require('./assets/arrowpng.png')} style={styles.logo} />
                        </TouchableOpacity>
                        <Text style={{ fontSize: 15, color: "#fff",marginTop: 35, marginLeft: 10, fontFamily: 'hamextrabold' }}>MEASUREMENT</Text>
                    </View> */}
                    <TouchableOpacity style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
                        onPress={() => this.addbtn()}
                    >
                        <Image source={require('./assets/cancanlogo.png')} style={{ width: 150, height: 140 }} />
                        <Text style={{ fontSize: 20, fontFamily: 'hamextrabold' }}>No Measurements</Text>
                        <Text style={{ fontSize: 15,fontFamily: 'hamextrabold', textAlign: 'center', marginLeft: 12, marginRight: 12 }}>
                            No Measurements please add measurements of kandoras
                      </Text>
                    </TouchableOpacity>
                    {
                        this.state.option ?
                            <View style={{ flex: 0.4, backgroundColor: "#181b51", justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{ color: '#fff', marginBottom: 20, fontSize: 20,fontFamily: 'hamextrabold' }}>GET MEASURED NOW</Text>
                                <TouchableOpacity style={{ backgroundColor: '#fff', marginBottom: 10, borderRadius: 100, borderWidth: 1, borderColor: "#181b51" }}
                                    onPress={() => { this.props.navigation.navigate('GetHelp') }}
                                >
                                    <Text style={{ color: '#181b51', padding: 10, paddingLeft: 50, paddingRight: 50, fontFamily: 'hamextrabold' }}>Using A.I. height above 140 cm</Text>
                                </TouchableOpacity>
                                <TouchableOpacity style={{ backgroundColor: '#fff', marginTop: 10, borderRadius: 100, borderWidth: 1, borderColor: "#181b51" }}
                                    onPress={() => { this.props.navigation.navigate('ManualMeasurement') }}
                                >
                                    <Text style={{ color: '#181b51', padding: 10, paddingLeft: 34, paddingRight: 34, fontFamily: 'hamextrabold' }}>Enter Manually supports all heights</Text>
                                </TouchableOpacity>
                            </View>
                            :
                            null
                    }
                    {
                        this.state.addbtn ?
                            <TouchableOpacity style={{ flex: 0.1, backgroundColor: "#181b51", justifyContent: 'center', alignItems: 'center' }}
                                onPress={() => this.Option()}
                            >
                                <Text style={{ color: "#fff", fontFamily: 'hamextrabold', fontSize: 18 }}>
                                    Add new Measurements
                           </Text>
                            </TouchableOpacity>
                            :
                            null
                    }
                </View>
            )
        }
        else {
            return <AppLoading />;
        }
    }
}
const styles = StyleSheet.create(
    {
        logocontainer: {
            flexDirection: 'row',
            alignItems: 'center',
        },
        logo: {
            width: 60,
            height: 25,
            tintColor: "#fff"
        },
    }
)
export default OptionMeasurement;