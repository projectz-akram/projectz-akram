/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

 import React from 'react';
 import {
   View,
   Text,
   TextInput,
   StyleSheet,
   ImageBackground,
   Image,
   TouchableOpacity,
   ScrollView,
   StatusBar,
 
   Dimensions
 } from 'react-native';

 const { width: WIDTH } = Dimensions.get('window')
 
 import AppLoading from 'expo-app-loading';
import * as Font from 'expo-font';

let customFonts = {
    'Hamelin': require('./assets/fonts/FontsFree-Net-Hamelin.ttf'),
    'caveat': require('./assets/fonts/Caveat-Medium.ttf'),
    'hambold': require('./assets/fonts/Hamlin-Bold.ttf'),
    'hamextrabold': require('./assets/fonts/Hamlin-ExtraBold.ttf'),
    'hamlight': require('./assets/fonts/Hamlin-Light.ttf'),
    'hamregular': require('./assets/fonts/Caveat-Medium.ttf'),
   
   
  };
 
 class Faq extends React.Component {

    state = {
        fontsLoaded: false,
      };
    
      async _loadFontsAsync() {
        await Font.loadAsync(customFonts);
        this.setState({ fontsLoaded: true });
      }
    
      componentDidMount() {
        this._loadFontsAsync();
      }
   render() {
    if(this.state.fontsLoaded){
     return (
 
       
      
         <View style={{flex:1}}>
               <Text>What is your delivery time?</Text>
               <Text>We normally orders between 4 to 7 working days. Express delivery is available in 2 working days subject to an additional charges.</Text>

            </View>
        



         
             
      

         
     )
    }
    else{
        return <AppLoading/>;
    }
   }
 }
 const styles = StyleSheet.create(
   {
     container: {
       flex: 1,
       width: null,
       height: null,
 
     },
     logocontainer: {
       flexDirection: 'row',
       alignItems: 'center',
 
     },
     logo: {
       width: 60,
       height: 60,
     },
     logotext: {
       color: "#fff",
       fontSize: 30,
       fontWeight: "500",
     },
     inputcontainer: {
       marginTop: 30,
       shadowOpacity: 1,
       shadowColor: 'red',
       shadowRadius: 10,
       shadowOffset: { width: 0, height: 0 }
 
 
     },
     input: {
       width: WIDTH - 55,
       height: 45,
 
       fontSize: 18,
       paddingLeft: 20,
       backgroundColor: "#fff",
 
     },
     btncontainer: {
       width: WIDTH - 55,
       height: 45,
 
       marginTop: 35,
       backgroundColor: "#232577",
       justifyContent: "center",
     },
     btnText: {
       color: 'rgba(255,255,255,0.7)',
       fontSize: 15,
       textAlign: 'center',
     },
   }
 )
 export default Faq;