import React from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    ScrollView,
    Image,
    TouchableOpacity,
    Dimensions,
} from 'react-native';
const { width: WIDTH } = Dimensions.get('window')
import AppLoading from 'expo-app-loading';
import * as Font from 'expo-font';
let customFonts = {
    'Hamelin': require('./assets/fonts/FontsFree-Net-Hamelin.ttf'),
    'caveat': require('./assets/fonts/Caveat-Medium.ttf'),
    'hambold': require('./assets/fonts/Hamlin-Bold.ttf'),
    'hamextrabold': require('./assets/fonts/Hamlin-ExtraBold.ttf'),
    'hamlight': require('./assets/fonts/Hamlin-Light.ttf'),
    'hamregular': require('./assets/fonts/Caveat-Medium.ttf'),
};
class ResultScreen extends React.Component {
    constructor() {
        super()
        this.state = {
            personal: true,
            stance: false,
        }
    }
    state = {
        fontsLoaded: false,
    };
    async _loadFontsAsync() {
        await Font.loadAsync(customFonts);
        this.setState({ fontsLoaded: true });
    }
    componentDidMount() {
        this._loadFontsAsync();
    }
    render() {
        if (this.state.fontsLoaded) {
            const { res } = this.props.route.params
            console.log(res);
            return (
                <View style={{ flex: 1 }}>
                    <View style={{ flex: 0.2, backgroundColor: "#181b51" }}>
                        <View style={{ flexDirection: 'row', marginTop: 40, marginLeft: 5 }}>
                            <TouchableOpacity onPress={() => this.props.navigation.navigate("MeasurementInput")} style={{ alignItems: "flex-start" }}>
                            <Image source={require('./assets/arrowpng.png')} resizeMode="contain" style={styles.logo} />
                                    
                                   
                            </TouchableOpacity>
                            <Text style={{ fontSize: 15, color: "#fff", alignItems: 'center', marginLeft: 60, fontFamily: 'hamextrabold',marginTop:10 }}>MEASUREMENTS</Text>
                        </View>
                    </View>
                    <ScrollView style={{ flex: 2.5, }}>
                        <View style={{ flex: 1, backgroundColor: "#fff", }}>
                            <Text style={styles.textstyle}>Shoulder to Shoulder Length in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder={JSON.stringify(res.Shoulder_to_Shoulder_Length_in_Inches)}
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Chest Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder={JSON.stringify(res.Chest_Size_in_Inches)}
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Biceps Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder={JSON.stringify(res.Biceps_Size_in_Inches)}
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Waist Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder={JSON.stringify(res.Waist_Size_in_Inches)}
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Arm Length in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder={JSON.stringify(res.Arm_Length_in_Inches)}
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Shoulder to Feet Length in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder={JSON.stringify(res.Shoulder_to_Feet_Length_in_Inches)}
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                             <Text style={styles.textstyle}>Wrist Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder={JSON.stringify(res.Wrist_Size_in_Inches)}
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                             <Text style={styles.textstyle}>Hips Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder={JSON.stringify(res.Hips_Size_in_Inches)}
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                            <Text style={styles.textstyle}>Neck Size in Inches:</Text>
                            <TextInput style={styles.Input}
                                placeholder={JSON.stringify(res.Neck_Size_in_Inches)}
                                placeholderTextColor='#B8B3B3'
                            // onChangeText={(fname) => this.setState({ fname })}
                            // value={this.state.fname}
                            // autoCapitalize="none"
                            />
                        </View>
                    </ScrollView>
                    <View style={{ flex: 0.1, marginTop: 15, borderTopWidth: 1, borderColor: '#000' }}>
                        <TouchableOpacity onPress={() => { this.props.navigation.navigate('Tutorial') }}>
                            <Text style={{ color: "#181b51", textAlign: 'center', fontSize: 18, fontFamily: 'hamextrabold' }}>WATCH TUTORIAL</Text>
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity onPress={() => { this.props.navigation.navigate('MeasurementInput') }} style={{ flex: 0.1, backgroundColor: "#181b51", justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ fontSize: 20, color: "#fff", fontFamily: 'hamextrabold' }}>Add Measurements </Text>
                    </TouchableOpacity>
                </View>
            )
        }
        else {
            return <AppLoading />;
        }
    }
}
const styles = StyleSheet.create(
    {
        logo: {
            width: 75,
            height: 45,
            tintColor: "#fff"

        },
        Input: {
            width: WIDTH - 50,
            marginLeft: 20,
            height: 40,
            fontSize: 15,
            marginTop: 7,
            fontFamily: 'hamextrabold',
            marginBottom: 7,
            borderRadius: 8,
            paddingLeft: 5,
            borderColor: '#7a42f4',
            borderWidth: 1
        },
        textstyle: {
            marginLeft: 20,
            fontSize: 15,
            fontFamily: 'hamextrabold',
            marginTop: 5
        },
    }
)
export default ResultScreen;