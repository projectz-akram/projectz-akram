import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import { createDrawerNavigator, DrawerItem,DrawerContent } from '@react-navigation/drawer'
import Home from './Screens/Home';
import Measurement from './Screens/Measurement';
import Side from './Screens/SideMenu';
import LogIn from './Screens/LogIn';
import Register from './Screens/Register';
import MeasurementInput from './Screens/MeasurementInput';
import Tutorial from './Screens/Tutorial';
import Splash from './Screens/Splash';
import SelectMeasurement from './Screens/SelectMeasurement';
import GetHelp from './Screens/GetHelp';
import Manualmeasurement from './Screens/ManualMeasurement';
import OptionMeasurement from './Screens/OptionMeasurement';
import About from './Screens/About';
import SideCamera from './Screens/SideCamera';
import ResultScreen from './Screens/ResultScreen';
const Stack = createStackNavigator();
const Drawer= createDrawerNavigator();
function DrawerRoots () {
  return(
     <Drawer.Navigator 
     initialRouteName="Measurement"
     screenOptions={{headerShown:true,
      headerStyle: {
        backgroundColor: '#181b51', //Set Header color
      },
      headerTintColor: '#fff',
    
    
    
    
    }}
     drawerContentOptions={{
      activeTintColor: '#e91e63',
      itemStyle: { marginVertical: 5 },
    }}
    
    //  drawerType={'back'}
     drawerContent={(props) => <Side {...props} />}
    >
       <Drawer.Screen name="Home"  component={Home}/>
        <Drawer.Screen name="Measurement" component={OptionMeasurement}/>
        <Drawer.Screen name="Tutorial" headerShown={false} component={Tutorial}/>
        <Drawer.Screen name="About us" component={About}/>
     </Drawer.Navigator>
  );
}
class MyStack extends React.Component {
  render(){
  return (
    <NavigationContainer independent={true}>
    <Stack.Navigator
      initialRouteName="Splash"
       screenOptions={{headerShown:false}}>
       <Stack.Screen name='Splash' component={Splash}/>
      <Stack.Screen name='Home' component={Home}/>
      <Stack.Screen name='LogIn' component={LogIn}/>
      <Stack.Screen name='Register' component={Register}/>
      <Stack.Screen name="MeasurementInput" component={MeasurementInput}/>
      <Stack.Screen name="SelectMeasurement" component={SelectMeasurement}/>
      <Stack.Screen name="SideCamera" component={SideCamera}/>
      <Stack.Screen name="ResultScreen" component={ResultScreen}/> 
      <Stack.Screen name="Tutorial" component={Tutorial}/>
      <Stack.Screen name="ManualMeasurement" component={Manualmeasurement}/>
      <Stack.Screen name="Measurement" component={Measurement}/>
      <Stack.Screen name="OptionMeasurement"  component={DrawerRoots}/>
      <Stack.Screen name="GetHelp" component={GetHelp}/>
    </Stack.Navigator>
    </NavigationContainer>
  );
  }
}
export default MyStack;